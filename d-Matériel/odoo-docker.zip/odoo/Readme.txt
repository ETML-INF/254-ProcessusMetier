Exécuter 'docker-compose up -d' dans ce répertoire
Se connecter à localhost:9000
Mot de passe : 'root' (modifiable dans config/odoo.config/odoo
